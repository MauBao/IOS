//
//  MySlider.swift
//  MusicApp
//
//  Created by Apple on 7/21/18.
//  Copyright © 2018 Apple. All rights reserved.
//

import UIKit

@IBDesignable
class MySlider: UISlider {

}
